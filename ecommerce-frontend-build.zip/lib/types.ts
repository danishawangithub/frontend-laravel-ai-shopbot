export interface Product {
  id: string;
  slug: string;
  title: string;
  price: number;
  fabric: string;
  category: string;
  images: string[];
  stock: number;
  description?: string;
}

export interface CartItem {
  productId: string;
  slug: string;
  title: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
  fabric: string;
}

export interface CheckoutData {
  name: string;
  phone: string;
  city: string;
  address: string;
  agreeToTerms: boolean;
}
