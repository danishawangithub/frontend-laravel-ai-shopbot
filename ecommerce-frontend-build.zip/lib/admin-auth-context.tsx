'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

interface AdminAuthContextType {
  isAuthenticated: boolean;
  adminName: string | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

// Demo credentials
const DEMO_EMAIL = 'admin@elegance.com';
const DEMO_PASSWORD = 'admin123';

export function AdminAuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminName, setAdminName] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Check localStorage on mount
  useEffect(() => {
    const savedAuth = localStorage.getItem('admin_authenticated');
    const savedName = localStorage.getItem('admin_name');
    
    if (savedAuth === 'true' && savedName) {
      setIsAuthenticated(true);
      setAdminName(savedName);
    }
    setIsLoaded(true);
  }, []);

  const login = (email: string, password: string): boolean => {
    if (email === DEMO_EMAIL && password === DEMO_PASSWORD) {
      setIsAuthenticated(true);
      setAdminName('Admin');
      localStorage.setItem('admin_authenticated', 'true');
      localStorage.setItem('admin_name', 'Admin');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setAdminName(null);
    localStorage.removeItem('admin_authenticated');
    localStorage.removeItem('admin_name');
  };

  if (!isLoaded) {
    return <>{children}</>;
  }

  return (
    <AdminAuthContext.Provider value={{ isAuthenticated, adminName, login, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within AdminAuthProvider');
  }
  return context;
}
