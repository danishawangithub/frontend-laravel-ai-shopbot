'use client';

import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const heroImages = [
  {
    id: 1,
    url: 'https://images.unsplash.com/photo-1584622570129-244dbaf3a97f?w=1200&h=800&fit=contain',
    title: 'Elegant Kurtis',
    description: 'Premium Pakistani kurtis collection'
  },
  {
    id: 2,
    url: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=1200&h=800&fit=contain',
    title: 'Designer Sarees',
    description: 'Traditional sarees with modern elegance'
  },
  {
    id: 3,
    url: 'https://images.unsplash.com/photo-1612447473816-3f0dd0d67b08?w=1200&h=800&fit=contain',
    title: 'Festive Dresses',
    description: 'Special occasion wedding collection'
  },
  {
    id: 4,
    url: 'https://images.unsplash.com/photo-1590080876-cd5e86a4e319?w=1200&h=800&fit=contain',
    title: 'Summer Collection',
    description: 'Light and elegant summer wear'
  }
];

export default function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(true);

  useEffect(() => {
    if (!isAutoplay) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoplay]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    setIsAutoplay(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroImages.length) % heroImages.length);
    setIsAutoplay(false);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
    setIsAutoplay(false);
  };

  return (
    <div className="relative w-full h-[600px] md:h-[700px] overflow-hidden bg-secondary/10">
      {/* Slides */}
      {heroImages.map((image, index) => (
        <div
          key={image.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out flex items-center justify-center ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img
            src={image.url}
            alt={image.title}
            className="w-full h-full object-contain"
          />
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-black/10" />
          
          {/* Content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white px-4">
              <h2 className="text-3xl md:text-5xl font-bold mb-3 text-balance">
                {image.title}
              </h2>
              <p className="text-lg md:text-xl opacity-90">
                {image.description}
              </p>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Buttons */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition"
        aria-label="Next slide"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {heroImages.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-2 rounded-full transition-all ${
              index === currentSlide
                ? 'bg-white w-8'
                : 'bg-white/50 w-2 hover:bg-white/75'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Autoplay Indicator */}
      <div className="absolute top-6 right-6 z-10">
        <button
          onClick={() => setIsAutoplay(!isAutoplay)}
          className="bg-white/30 hover:bg-white/50 text-white px-4 py-2 rounded-full text-sm font-semibold transition"
        >
          {isAutoplay ? 'Playing' : 'Paused'}
        </button>
      </div>
    </div>
  );
}
