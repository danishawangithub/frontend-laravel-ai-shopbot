import { sizes } from '@/lib/products';

interface SizeSelectorProps {
  selectedSize: string;
  onSizeChange: (size: string) => void;
  onOpenSizeChart: () => void;
}

export default function SizeSelector({
  selectedSize,
  onSizeChange,
  onOpenSizeChart,
}: SizeSelectorProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <label className="font-semibold text-foreground">Size</label>
        <button
          onClick={onOpenSizeChart}
          className="text-sm text-primary hover:underline"
        >
          View Size Chart
        </button>
      </div>

      <div className="flex gap-2 flex-wrap">
        {sizes.map((size) => (
          <button
            key={size}
            onClick={() => onSizeChange(size)}
            className={`px-4 py-2 border-2 rounded font-medium transition ${
              selectedSize === size
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border text-foreground hover:border-primary'
            }`}
          >
            {size}
          </button>
        ))}
      </div>
    </div>
  );
}
