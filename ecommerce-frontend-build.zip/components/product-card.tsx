import Link from 'next/link';
import Image from 'next/image';
import { Product } from '@/lib/types';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/product/${product.slug}`}>
      <div className="bg-card rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer">
        {/* Image Container */}
        <div className="relative w-full aspect-square bg-muted overflow-hidden">
          <Image
            src={product.images[0]}
            alt={product.title}
            fill
            className="object-cover hover:scale-105 transition-transform duration-300"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
          />
        </div>

        {/* Product Info */}
        <div className="p-4">
          {/* Category Badge */}
          <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">
            {product.category}
          </p>

          {/* Title */}
          <h3 className="text-base font-semibold text-foreground mb-2 line-clamp-2">
            {product.title}
          </h3>

          {/* Fabric */}
          <p className="text-sm text-muted-foreground mb-3">
            {product.fabric}
          </p>

          {/* Price and Button */}
          <div className="flex items-center justify-between">
            <span className="text-lg font-semibold text-primary">
              ₹{product.price.toLocaleString()}
            </span>
            <button className="px-3 py-2 bg-primary text-primary-foreground rounded text-sm font-medium hover:opacity-90 transition">
              View
            </button>
          </div>

          {/* Stock Status */}
          {product.stock <= 5 && (
            <p className="text-xs text-destructive mt-2 font-semibold">
              Only {product.stock} left!
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}
