'use client';

import Image from 'next/image';
import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface ImageGalleryProps {
  images: string[];
  title: string;
}

export default function ImageGallery({ images, title }: ImageGalleryProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);

  const handlePrevious = () => {
    setSelectedIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setSelectedIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  // Show up to 6 thumbnails, center the currently selected one when possible
  const getThumbnailIndices = () => {
    const thumbnailCount = Math.min(6, images.length);
    const indices: number[] = [];

    if (images.length <= thumbnailCount) {
      return Array.from({ length: images.length }, (_, i) => i);
    }

    const halfVisible = Math.floor(thumbnailCount / 2);
    let start = Math.max(0, selectedIndex - halfVisible);
    let end = Math.min(images.length, start + thumbnailCount);

    if (end - start < thumbnailCount) {
      start = Math.max(0, end - thumbnailCount);
    }

    for (let i = start; i < end; i++) {
      indices.push(i);
    }

    return indices;
  };

  const thumbnailIndices = getThumbnailIndices();

  return (
    <div className="flex flex-col gap-4">
      {/* Main Image */}
      <div className="relative w-full aspect-square bg-secondary rounded-lg overflow-hidden">
        <Image
          src={images[selectedIndex]}
          alt={`${title} - Image ${selectedIndex + 1}`}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 50vw"
          priority
        />

        {/* Navigation Arrows - Desktop */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrevious}
              className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition"
              aria-label="Previous image"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition"
              aria-label="Next image"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Image Counter */}
        {images.length > 1 && (
          <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-1 rounded text-sm">
            {selectedIndex + 1} / {images.length}
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {images.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-2">
          {thumbnailIndices.map((index) => (
            <button
              key={index}
              onClick={() => setSelectedIndex(index)}
              className={`relative w-16 h-16 flex-shrink-0 rounded border-2 overflow-hidden transition ${
                selectedIndex === index
                  ? 'border-primary'
                  : 'border-border hover:border-primary'
              }`}
              aria-label={`View image ${index + 1}`}
            >
              <Image
                src={images[index]}
                alt={`Thumbnail ${index + 1}`}
                fill
                className="object-cover"
                sizes="64px"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
