'use client';

import { useState } from 'react';
import { CheckoutData } from '@/lib/types';

interface CheckoutFormProps {
  onSubmit: (data: CheckoutData) => void;
  isLoading?: boolean;
}

export default function CheckoutForm({ onSubmit, isLoading = false }: CheckoutFormProps) {
  const [formData, setFormData] = useState<CheckoutData>({
    name: '',
    phone: '',
    city: '',
    address: '',
    agreeToTerms: false,
  });

  const [errors, setErrors] = useState<Partial<CheckoutData>>({});

  const validateForm = (): boolean => {
    const newErrors: Partial<CheckoutData> = {};

    if (!formData.name.trim()) {
      newErrors.name = true;
    }

    if (!formData.phone.trim() || formData.phone.length < 10) {
      newErrors.phone = true;
    }

    if (!formData.city.trim()) {
      newErrors.city = true;
    }

    if (!formData.address.trim()) {
      newErrors.address = true;
    }

    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = true;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';

    setFormData((prev) => ({
      ...prev,
      [name]: isCheckbox ? (e.target as HTMLInputElement).checked : value,
    }));

    // Clear error for this field
    if (errors[name as keyof CheckoutData]) {
      setErrors((prev) => ({
        ...prev,
        [name]: undefined,
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Full Name */}
      <div>
        <label className="block text-sm font-semibold text-foreground mb-2">
          Full Name *
        </label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Enter your full name"
          className={`w-full px-4 py-2 border rounded text-foreground placeholder:text-muted-foreground transition ${
            errors.name ? 'border-destructive' : 'border-border focus:border-primary'
          } focus:outline-none`}
        />
        {errors.name && (
          <p className="text-sm text-destructive mt-1">Name is required</p>
        )}
      </div>

      {/* Phone Number */}
      <div>
        <label className="block text-sm font-semibold text-foreground mb-2">
          Phone Number *
        </label>
        <input
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="03001234567"
          className={`w-full px-4 py-2 border rounded text-foreground placeholder:text-muted-foreground transition ${
            errors.phone ? 'border-destructive' : 'border-border focus:border-primary'
          } focus:outline-none`}
        />
        {errors.phone && (
          <p className="text-sm text-destructive mt-1">
            Enter a valid phone number
          </p>
        )}
      </div>

      {/* City */}
      <div>
        <label className="block text-sm font-semibold text-foreground mb-2">
          City *
        </label>
        <input
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
          placeholder="e.g., Karachi, Lahore"
          className={`w-full px-4 py-2 border rounded text-foreground placeholder:text-muted-foreground transition ${
            errors.city ? 'border-destructive' : 'border-border focus:border-primary'
          } focus:outline-none`}
        />
        {errors.city && (
          <p className="text-sm text-destructive mt-1">City is required</p>
        )}
      </div>

      {/* Address */}
      <div>
        <label className="block text-sm font-semibold text-foreground mb-2">
          Delivery Address *
        </label>
        <textarea
          name="address"
          value={formData.address}
          onChange={handleChange}
          placeholder="Enter your complete delivery address"
          rows={3}
          className={`w-full px-4 py-2 border rounded text-foreground placeholder:text-muted-foreground transition resize-none ${
            errors.address ? 'border-destructive' : 'border-border focus:border-primary'
          } focus:outline-none`}
        />
        {errors.address && (
          <p className="text-sm text-destructive mt-1">Address is required</p>
        )}
      </div>

      {/* Terms & Conditions */}
      <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded">
        <input
          type="checkbox"
          name="agreeToTerms"
          id="agreeToTerms"
          checked={formData.agreeToTerms}
          onChange={handleChange}
          className="mt-1 w-4 h-4 rounded border border-border cursor-pointer"
        />
        <label htmlFor="agreeToTerms" className="text-sm text-foreground cursor-pointer">
          I agree to the{' '}
          <a href="#" className="text-primary hover:underline">
            terms and conditions
          </a>
          {' '}and understand that orders are final and
          <a href="#" className="text-primary hover:underline">
            {' '}
            7-day exchanges
          </a>
          {' '}only apply within that period. *
        </label>
      </div>
      {errors.agreeToTerms && (
        <p className="text-sm text-destructive -mt-3">
          You must agree to the terms
        </p>
      )}

      {/* Submit Button */}
      <button
        type="submit"
        disabled={isLoading}
        className="w-full py-3 bg-primary text-primary-foreground rounded font-semibold hover:opacity-90 transition disabled:opacity-50"
      >
        {isLoading ? 'Processing...' : 'Place Order (Cash on Delivery)'}
      </button>

      <p className="text-xs text-muted-foreground text-center">
        You will receive a call to confirm your order after submission.
      </p>
    </form>
  );
}
