'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { CheckCircle2, Phone, MapPin, DollarSign } from 'lucide-react';

interface OrderDetails {
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  city: string;
  address: string;
  items: Array<{
    title: string;
    quantity: number;
    price: number;
  }>;
  totalAmount: number;
  orderDate: string;
}

export default function ThankYouPage() {
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get order details from sessionStorage
    const lastOrder = sessionStorage.getItem('lastOrder');
    if (lastOrder) {
      try {
        setOrderDetails(JSON.parse(lastOrder));
        // Clear the stored order after retrieving it
        sessionStorage.removeItem('lastOrder');
      } catch (error) {
        console.error('Failed to parse order details:', error);
      }
    }
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className="bg-background min-h-screen flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />

      <div className="bg-background min-h-screen">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Success Message */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <div className="bg-green-600 rounded-full p-4">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
            </div>

            <h1 className="text-4xl font-bold text-foreground mb-4">
              Order Confirmed!
            </h1>

            <p className="text-lg text-muted-foreground mb-2">
              Thank you for your purchase
            </p>

            {orderDetails ? (
              <p className="text-xl font-semibold text-primary">
                Order #{orderDetails.orderNumber}
              </p>
            ) : (
              <p className="text-foreground">
                Your order has been successfully placed.
              </p>
            )}
          </div>

          {/* Order Details Card */}
          {orderDetails && (
            <div className="bg-card rounded-lg border border-border overflow-hidden mb-8">
              {/* Header */}
              <div className="bg-secondary border-b border-border p-6">
                <div className="grid grid-cols-2 gap-4 sm:gap-6">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Order Number</p>
                    <p className="text-lg font-bold text-foreground">
                      {orderDetails.orderNumber}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground mb-1">Order Date</p>
                    <p className="text-lg font-bold text-foreground">
                      {orderDetails.orderDate}
                    </p>
                  </div>
                </div>
              </div>

              {/* Customer Details */}
              <div className="p-6 border-b border-border">
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  Delivery Details
                </h2>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-foreground">
                        {orderDetails.customerName}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {orderDetails.address}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {orderDetails.city}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-muted-foreground">Contact Number</p>
                      <p className="font-semibold text-foreground">
                        {orderDetails.customerPhone}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Order Items */}
              <div className="p-6 border-b border-border">
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  Order Items
                </h2>
                <div className="space-y-3">
                  {orderDetails.items.map((item, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center pb-3 border-b border-border last:border-b-0 last:pb-0"
                    >
                      <div>
                        <p className="font-semibold text-foreground line-clamp-1">
                          {item.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Quantity: {item.quantity}
                        </p>
                      </div>
                      <p className="font-semibold text-foreground">
                        ₹{(item.price * item.quantity).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="p-6 bg-secondary">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-primary" />
                    <span className="font-semibold text-foreground">Total Amount:</span>
                  </div>
                  <span className="text-2xl font-bold text-primary">
                    ₹{orderDetails.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Next Steps */}
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              What Happens Next?
            </h2>
            <ol className="space-y-3 text-foreground">
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  1
                </span>
                <span>
                  You will receive a confirmation call from our team within 2-4 hours
                  to verify your order and delivery details.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  2
                </span>
                <span>
                  Your order will be shipped within 24 hours of confirmation.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  3
                </span>
                <span>
                  You can pay using cash on delivery when the package arrives.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  4
                </span>
                <span>
                  7-day exchange policy applies from the date of delivery if needed.
                </span>
              </li>
            </ol>
          </div>

          {/* Policy Information */}
          <div className="bg-secondary rounded-lg p-6 mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Important Information
            </h2>
            <ul className="space-y-2 text-foreground text-sm">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-0.5">•</span>
                <span>
                  <span className="font-semibold">Nationwide Delivery:</span> We deliver
                  across all major cities in Pakistan.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-0.5">•</span>
                <span>
                  <span className="font-semibold">7-Day Exchange:</span> You can exchange
                  items within 7 days of delivery without any extra charge.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-0.5">•</span>
                <span>
                  <span className="font-semibold">Payment:</span> Please keep cash ready
                  for the delivery.
                </span>
              </li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/shop">
              <button className="w-full sm:w-auto px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:opacity-90 transition">
                Continue Shopping
              </button>
            </Link>
            <Link href="/">
              <button className="w-full sm:w-auto px-8 py-3 border border-primary text-primary rounded font-semibold hover:bg-secondary transition">
                Back to Home
              </button>
            </Link>
          </div>

          {/* Support */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground">
              Need help?{' '}
              <a href="#" className="text-primary hover:underline font-semibold">
                Contact our support team
              </a>
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
