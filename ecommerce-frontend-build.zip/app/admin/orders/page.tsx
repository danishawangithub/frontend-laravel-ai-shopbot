'use client';

import { useState } from 'react';
import { useAdmin, Order } from '@/lib/admin-context';
import { Trash2, Edit2, X } from 'lucide-react';

export default function OrdersPage() {
  const { orders, updateOrder, deleteOrder } = useAdmin();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Shipped' | 'Delivered'>('All');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editStatus, setEditStatus] = useState<'Pending' | 'Shipped' | 'Delivered'>('Pending');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Filter and search orders
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || order.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleUpdateStatus = (id: string, newStatus: 'Pending' | 'Shipped' | 'Delivered') => {
    updateOrder(id, { status: newStatus });
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    deleteOrder(id);
    setDeleteConfirm(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered':
        return '#10b981';
      case 'Shipped':
        return '#3b82f6';
      case 'Pending':
        return '#f59e0b';
      default:
        return '#6b7280';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Orders</h1>
        <p className="text-muted-foreground">Manage and track all customer orders</p>
      </div>

      {/* Filters */}
      <div className="bg-card rounded-lg shadow p-4 md:p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Search Orders</label>
            <input
              type="text"
              placeholder="Search by order ID, customer name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Filter by Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option>All</option>
              <option>Pending</option>
              <option>Shipped</option>
              <option>Delivered</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-card rounded-lg shadow overflow-hidden">
        {filteredOrders.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-secondary/30 border-b border-border">
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Order ID</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Customer</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Amount</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Items</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Status</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Date</th>
                  <th className="px-4 md:px-6 py-4 text-left text-sm font-semibold text-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="border-b border-border hover:bg-secondary/10">
                    <td className="px-4 md:px-6 py-4 text-sm font-medium text-foreground">{order.orderNumber}</td>
                    <td className="px-4 md:px-6 py-4 text-sm text-foreground">
                      <div>
                        <p className="font-medium">{order.customerName}</p>
                        <p className="text-xs text-muted-foreground">{order.customerEmail}</p>
                      </div>
                    </td>
                    <td className="px-4 md:px-6 py-4 text-sm font-medium text-foreground">Rs. {order.total}</td>
                    <td className="px-4 md:px-6 py-4 text-sm text-foreground">{order.items}</td>
                    <td className="px-4 md:px-6 py-4">
                      {editingId === order.id ? (
                        <div className="flex gap-2">
                          <select
                            value={editStatus}
                            onChange={(e) => setEditStatus(e.target.value as any)}
                            className="text-xs px-2 py-1 border border-border rounded"
                          >
                            <option>Pending</option>
                            <option>Shipped</option>
                            <option>Delivered</option>
                          </select>
                          <button
                            onClick={() => handleUpdateStatus(order.id, editStatus)}
                            className="text-xs px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="text-xs px-3 py-1 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <span
                          className="px-3 py-1 rounded-full text-xs font-semibold text-white"
                          style={{ backgroundColor: getStatusColor(order.status) }}
                        >
                          {order.status}
                        </span>
                      )}
                    </td>
                    <td className="px-4 md:px-6 py-4 text-sm text-muted-foreground">{order.date}</td>
                    <td className="px-4 md:px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setEditingId(order.id);
                            setEditStatus(order.status);
                          }}
                          className="p-2 rounded-lg hover:bg-secondary/30 transition"
                          title="Edit status"
                        >
                          <Edit2 className="w-4 h-4" style={{ color: '#BB454E' }} />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(order.id)}
                          className="p-2 rounded-lg hover:bg-red-50 transition"
                          title="Delete order"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 text-center">
            <p className="text-muted-foreground">No orders found</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-card rounded-lg shadow-lg max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-foreground mb-4">Delete Order?</h3>
            <p className="text-muted-foreground mb-6">Are you sure you want to delete this order? This action cannot be undone.</p>
            <div className="flex gap-3">
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 px-4 py-2 rounded-lg font-medium text-white transition"
                style={{ backgroundColor: '#BB454E' }}
              >
                Delete
              </button>
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 px-4 py-2 rounded-lg font-medium text-foreground border border-border hover:bg-secondary/30 transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
