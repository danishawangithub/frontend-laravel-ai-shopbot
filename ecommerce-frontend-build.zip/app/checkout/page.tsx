'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import CheckoutForm from '@/components/checkout-form';
import { useCart } from '@/lib/cart-context';
import { CheckoutData } from '@/lib/types';
import Image from 'next/image';
import Link from 'next/link';

export default function CheckoutPage() {
  const router = useRouter();
  const { items, getTotalPrice, clearCart } = useCart();
  const [isLoading, setIsLoading] = useState(false);
  const totalPrice = getTotalPrice();

  if (items.length === 0) {
    return (
      <>
        <Navbar />
        <div className="bg-background min-h-screen">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground mb-4">
                Your cart is empty
              </h1>
              <p className="text-muted-foreground mb-6">
                Add items to your cart before proceeding to checkout.
              </p>
              <Link href="/shop">
                <button className="px-6 py-3 bg-primary text-primary-foreground rounded font-semibold hover:opacity-90 transition">
                  Continue Shopping
                </button>
              </Link>
            </div>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const handleCheckoutSubmit = async (data: CheckoutData) => {
    setIsLoading(true);

    try {
      // Simulate order processing
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Store order details in sessionStorage
      const orderNumber = `ORD-${Date.now()}`;
      const orderDetails = {
        orderNumber,
        customerName: data.name,
        customerPhone: data.phone,
        city: data.city,
        address: data.address,
        items: items,
        totalAmount: totalPrice,
        orderDate: new Date().toLocaleDateString(),
      };

      sessionStorage.setItem('lastOrder', JSON.stringify(orderDetails));

      // Clear cart
      clearCart();

      // Redirect to thank you page
      router.push('/thank-you');
    } catch (error) {
      console.error('Order submission failed:', error);
      alert('There was an error processing your order. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Navbar />

      <div className="bg-background min-h-screen">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-4xl font-bold text-foreground mb-8">Checkout</h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Checkout Form - Left Column */}
            <div className="lg:col-span-2">
              <div className="bg-card rounded-lg p-6 border border-border">
                <h2 className="text-2xl font-bold text-foreground mb-6">Delivery Information</h2>
                <CheckoutForm onSubmit={handleCheckoutSubmit} isLoading={isLoading} />
              </div>
            </div>

            {/* Order Summary - Right Column */}
            <div className="lg:col-span-1">
              {/* Summary Card */}
              <div className="bg-secondary rounded-lg border border-border overflow-hidden sticky top-24">
                {/* Header */}
                <div className="bg-foreground/5 p-4 border-b border-border">
                  <h2 className="text-lg font-bold text-foreground">Order Summary</h2>
                </div>

                {/* Items List */}
                <div className="p-4 max-h-96 overflow-y-auto border-b border-border">
                  {items.map((item) => (
                    <div
                      key={`${item.productId}-${item.size}`}
                      className="flex gap-3 mb-4 pb-4 border-b border-border last:border-b-0 last:mb-0 last:pb-0"
                    >
                      {/* Image */}
                      <div className="relative w-16 h-16 flex-shrink-0 rounded bg-background">
                        <Image
                          src={item.image}
                          alt={item.title}
                          fill
                          className="object-cover rounded"
                          sizes="64px"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground text-sm line-clamp-2">
                          {item.title}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          Size: {item.size}
                        </p>
                        <p className="text-sm font-semibold text-primary mt-1">
                          ₹{item.price.toLocaleString()} x {item.quantity}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="p-4 space-y-3">
                  {/* Subtotal */}
                  <div className="flex justify-between text-foreground">
                    <span>Subtotal ({items.length} items):</span>
                    <span className="font-semibold">₹{totalPrice.toLocaleString()}</span>
                  </div>

                  {/* Shipping */}
                  <div className="flex justify-between text-foreground pb-3 border-b border-border">
                    <span>Shipping:</span>
                    <span className="font-semibold text-green-600">Free</span>
                  </div>

                  {/* Total */}
                  <div className="flex justify-between items-center pt-3">
                    <span className="font-bold text-foreground">Total:</span>
                    <span className="text-2xl font-bold text-primary">
                      ₹{totalPrice.toLocaleString()}
                    </span>
                  </div>

                  {/* Info Box */}
                  <div className="bg-primary/10 border border-primary/20 rounded p-3 text-sm text-foreground space-y-2">
                    <p>
                      <span className="font-semibold">Payment Method:</span> Cash on Delivery
                    </p>
                    <p>
                      <span className="font-semibold">Delivery:</span> Nationwide available
                    </p>
                    <p className="text-xs opacity-80">
                      You&apos;ll receive a confirmation call after placing your order.
                    </p>
                  </div>
                </div>
              </div>

              {/* Edit Cart Link */}
              <div className="mt-4">
                <Link href="/cart">
                  <button className="w-full py-2 border border-border rounded font-medium text-foreground hover:bg-secondary transition">
                    Edit Cart
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
