'use client';

import { useState } from 'react';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import ImageGallery from '@/components/image-gallery';
import SizeSelector from '@/components/size-selector';
import QuantitySelector from '@/components/quantity-selector';
import SizeChartModal from '@/components/size-chart-modal';
import { products } from '@/lib/products';
import { useCart } from '@/lib/cart-context';
import Link from 'next/link';
import { ChevronRight, CheckCircle2, RotateCcw } from 'lucide-react';

interface ProductDetailPageProps {
  params: {
    slug: string;
  };
}

export default function ProductDetailPage({
  params: { slug },
}: ProductDetailPageProps) {
  const product = products.find((p) => p.slug === slug);
  const { addToCart } = useCart();

  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [showSizeChart, setShowSizeChart] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);

  if (!product) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Product Not Found</h1>
            <Link href="/shop" className="text-primary hover:underline">
              Back to Shop
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Please select a size');
      return;
    }

    addToCart({
      productId: product.id,
      slug: product.slug,
      title: product.title,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      quantity: quantity,
      fabric: product.fabric,
    });

    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
    setSelectedSize('');
    setQuantity(1);
  };

  // Get related products (same category, different product)
  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <>
      <Navbar />

      <div className="bg-background min-h-screen">
        {/* Breadcrumb */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Link href="/" className="hover:text-primary">
              Home
            </Link>
            <ChevronRight className="w-4 h-4" />
            <Link href="/shop" className="hover:text-primary">
              Shop
            </Link>
            <ChevronRight className="w-4 h-4" />
            <span className="text-foreground font-semibold truncate">
              {product.title}
            </span>
          </div>
        </div>

        {/* Product Detail */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left: Image Gallery */}
            <div>
              <ImageGallery images={product.images} title={product.title} />
            </div>

            {/* Right: Product Info */}
            <div className="space-y-6">
              {/* Category */}
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  {product.category}
                </p>
              </div>

              {/* Title & Price */}
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
                  {product.title}
                </h1>
                <p className="text-2xl font-bold text-primary">
                  ₹{product.price.toLocaleString()}
                </p>
              </div>

              {/* Fabric & Stock */}
              <div className="space-y-2">
                <p className="text-foreground">
                  <span className="font-semibold">Fabric:</span> {product.fabric}
                </p>
                <p className="text-foreground">
                  <span className="font-semibold">Stock:</span>{' '}
                  <span className={product.stock > 0 ? 'text-green-600' : 'text-destructive'}>
                    {product.stock > 0 ? `${product.stock} available` : 'Out of Stock'}
                  </span>
                </p>
              </div>

              {/* Description */}
              {product.description && (
                <div>
                  <p className="text-foreground">{product.description}</p>
                </div>
              )}

              {/* Size Selector */}
              <div>
                <SizeSelector
                  selectedSize={selectedSize}
                  onSizeChange={setSelectedSize}
                  onOpenSizeChart={() => setShowSizeChart(true)}
                />
              </div>

              {/* Quantity Selector */}
              <div>
                <QuantitySelector
                  quantity={quantity}
                  onQuantityChange={setQuantity}
                  maxStock={Math.min(product.stock, 10)}
                />
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className={`w-full py-3 rounded font-semibold text-lg transition ${
                  addedToCart
                    ? 'bg-green-600 text-white'
                    : product.stock === 0
                      ? 'bg-muted text-muted-foreground cursor-not-allowed'
                      : 'bg-primary text-primary-foreground hover:opacity-90'
                }`}
              >
                {addedToCart ? (
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    Added to Cart!
                  </div>
                ) : product.stock === 0 ? (
                  'Out of Stock'
                ) : (
                  'Add to Cart'
                )}
              </button>

              {/* Trust Badges */}
              <div className="border-t border-b border-border py-6 space-y-3">
                <div className="flex items-start gap-3">
                  <RotateCcw className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">7-Day Exchange</p>
                    <p className="text-sm text-muted-foreground">Easy returns within 7 days</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">Cash on Delivery</p>
                    <p className="text-sm text-muted-foreground">Pay when you receive</p>
                  </div>
                </div>
              </div>

              {/* Shipping Info */}
              <div className="bg-secondary/50 p-4 rounded">
                <p className="text-sm text-foreground">
                  <span className="font-semibold">Delivery:</span> Nationwide delivery
                  available. Orders placed before 3 PM usually ship the same day.
                </p>
              </div>
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 border-t border-border pt-12">
              <h2 className="text-2xl font-bold text-foreground mb-8">
                Similar Products
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map((relatedProduct) => (
                  <Link key={relatedProduct.id} href={`/product/${relatedProduct.slug}`}>
                    <div className="bg-card rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="relative w-full aspect-square bg-muted">
                        {/* Product Image Placeholder */}
                        <img
                          src={relatedProduct.images[0]}
                          alt={relatedProduct.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-foreground line-clamp-2 mb-2">
                          {relatedProduct.title}
                        </h3>
                        <p className="text-lg font-bold text-primary">
                          ₹{relatedProduct.price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Size Chart Modal */}
      <SizeChartModal
        isOpen={showSizeChart}
        onClose={() => setShowSizeChart(false)}
      />

      <Footer />
    </>
  );
}
