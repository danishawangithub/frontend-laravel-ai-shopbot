'use client';

import { useState, useMemo } from 'react';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import ProductCard from '@/components/product-card';
import { products, categories, priceRanges } from '@/lib/products';
import { Product } from '@/lib/types';
import { X, Filter } from 'lucide-react';

export default function ShopPage() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedPriceRanges, setSelectedPriceRanges] = useState<number[]>([]);
  const [sortBy, setSortBy] = useState<'newest' | 'price-low' | 'price-high'>('newest');
  const [showFilters, setShowFilters] = useState(true);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Category filter
    if (selectedCategories.length > 0) {
      result = result.filter((p) => selectedCategories.includes(p.category));
    }

    // Price filter
    if (selectedPriceRanges.length > 0) {
      result = result.filter((p) => {
        return selectedPriceRanges.some((rangeIndex) => {
          const range = priceRanges[rangeIndex];
          return p.price >= range.min && p.price <= range.max;
        });
      });
    }

    // Sorting
    if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [selectedCategories, selectedPriceRanges, sortBy]);

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  const togglePriceRange = (index: number) => {
    setSelectedPriceRanges((prev) =>
      prev.includes(index)
        ? prev.filter((i) => i !== index)
        : [...prev, index]
    );
  };

  const hasActiveFilters =
    selectedCategories.length > 0 || selectedPriceRanges.length > 0;

  const clearFilters = () => {
    setSelectedCategories([]);
    setSelectedPriceRanges([]);
  };

  return (
    <>
      <Navbar />

      <div className="bg-background min-h-screen">
        {/* Header */}
        <div className="bg-secondary border-b border-border">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-4xl font-bold text-foreground">Shop Collection</h1>
            <p className="text-muted-foreground mt-2">
              Browse our curated selection of premium Pakistani women&apos;s clothing
            </p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex gap-6">
            {/* Filters Sidebar - Desktop */}
            <aside className="hidden md:block w-64 flex-shrink-0">
              <div className="bg-card rounded-lg p-6 border border-border">
                <h2 className="text-lg font-bold text-foreground mb-4">Filters</h2>

                {/* Categories */}
                <div className="mb-6">
                  <h3 className="font-semibold text-foreground mb-3">Category</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <label key={category} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedCategories.includes(category)}
                          onChange={() => toggleCategory(category)}
                          className="w-4 h-4 rounded border-border"
                        />
                        <span className="text-foreground">{category}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <h3 className="font-semibold text-foreground mb-3">Price Range</h3>
                  <div className="space-y-2">
                    {priceRanges.map((range, index) => (
                      <label key={index} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedPriceRanges.includes(index)}
                          onChange={() => togglePriceRange(index)}
                          className="w-4 h-4 rounded border-border"
                        />
                        <span className="text-foreground">{range.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Clear Filters */}
                {hasActiveFilters && (
                  <button
                    onClick={clearFilters}
                    className="w-full py-2 text-primary hover:bg-secondary rounded transition font-medium"
                  >
                    Clear All Filters
                  </button>
                )}
              </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1">
              {/* Controls */}
              <div className="flex items-center justify-between gap-4 mb-6">
                {/* Mobile Filter Toggle */}
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="md:hidden flex items-center gap-2 px-4 py-2 border border-border rounded text-foreground"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                </button>

                {/* Sort */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                  className="px-4 py-2 border border-border rounded text-foreground bg-card"
                >
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>

                {/* Results Count */}
                <p className="text-sm text-muted-foreground">
                  {filteredProducts.length} items
                </p>
              </div>

              {/* Active Filters Display */}
              {hasActiveFilters && (
                <div className="mb-6 p-4 bg-secondary rounded flex items-center gap-2 justify-between">
                  <div className="flex items-center gap-2 flex-wrap">
                    {selectedCategories.map((cat) => (
                      <span
                        key={cat}
                        className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm flex items-center gap-2"
                      >
                        {cat}
                        <button
                          onClick={() => toggleCategory(cat)}
                          className="hover:opacity-80"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                    {selectedPriceRanges.map((index) => (
                      <span
                        key={index}
                        className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm flex items-center gap-2"
                      >
                        {priceRanges[index].label}
                        <button
                          onClick={() => togglePriceRange(index)}
                          className="hover:opacity-80"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={clearFilters}
                    className="text-primary hover:underline text-sm whitespace-nowrap"
                  >
                    Clear All
                  </button>
                </div>
              )}

              {/* Product Grid */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <p className="text-muted-foreground text-lg">
                    No products found matching your filters.
                  </p>
                  <button
                    onClick={clearFilters}
                    className="mt-4 text-primary hover:underline font-medium"
                  >
                    Clear filters and try again
                  </button>
                </div>
              )}
            </main>

            {/* Mobile Filters */}
            {showFilters && (
              <div className="md:hidden fixed inset-0 bg-black/50 z-40 flex items-end">
                <div className="w-full bg-card rounded-t-lg p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold text-foreground">Filters</h2>
                    <button onClick={() => setShowFilters(false)}>
                      <X className="w-6 h-6" />
                    </button>
                  </div>

                  {/* Categories */}
                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Category</h3>
                    <div className="space-y-2">
                      {categories.map((category) => (
                        <label key={category} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedCategories.includes(category)}
                            onChange={() => toggleCategory(category)}
                            className="w-4 h-4 rounded border-border"
                          />
                          <span className="text-foreground">{category}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Price Range */}
                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Price Range</h3>
                    <div className="space-y-2">
                      {priceRanges.map((range, index) => (
                        <label key={index} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedPriceRanges.includes(index)}
                            onChange={() => togglePriceRange(index)}
                            className="w-4 h-4 rounded border-border"
                          />
                          <span className="text-foreground">{range.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Close Button */}
                  <button
                    onClick={() => setShowFilters(false)}
                    className="w-full py-3 bg-primary text-primary-foreground rounded font-semibold"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
